/**
 * @file lib/email/sendPayrollReceiptEmail.ts
 * SERVER-SIDE ONLY — never import in client components.
 *
 * Sends the payroll receipt email via Resend, attaching the PDF generated
 * by generateReceiptPdf.ts.
 *
 * From address is fixed at contact@salden.xyz for ALL payroll receipt
 * emails, regardless of whether the payment was triggered manually by the
 * employer or autonomously by the Salden AI Payroll Agent. The email body
 * text differs based on `executedBy` so the employer always knows who
 * actually carried out the payment.
 */

import { Resend } from 'resend';
import { generateReceiptPdf, type ReceiptPdfInput } from './generateReceiptPdf';

const FROM_ADDRESS = 'Salden <contact@salden.xyz>';
const APP_URL = process.env.NEXT_PUBLIC_APP_URL ?? 'https://app.salden.xyz';
const LOGO_URL = `${APP_URL}/images/salden-logo.png`;

function getResendClient(): Resend {
  const apiKey = process.env.RESEND_API_KEY;
  if (!apiKey) throw new Error('RESEND_API_KEY is not configured');
  return new Resend(apiKey);
}

export interface PayrollReceiptEmailInput extends ReceiptPdfInput {
  recipientEmail: string;
  walletAddress:  string;   // employer wallet — shown in the email body
}

export interface PayrollReceiptEmailResult {
  status:  'sent' | 'failed';
  message: string;
}

function buildSummaryLine(executedBy: 'manual' | 'ai_agent'): string {
  return executedBy === 'ai_agent'
    ? 'This payroll run was executed autonomously by the Salden AI Payroll Agent on your behalf.'
    : 'This payroll run was executed manually by you.';
}

function escapeHtml(value: string): string {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function buildEmailHtml(input: PayrollReceiptEmailInput): string {
  const summary = buildSummaryLine(input.executedBy);
  const fmtDate = new Date(input.timestamp).toLocaleDateString('en-US', {
    year: 'numeric', month: 'long', day: 'numeric',
  });

  // /api/payroll-receipt/send accepts these fields straight from the
  // request body — ref, remark, token, and walletAddress are NOT
  // guaranteed to be safe, trusted, or even correctly-shaped strings by
  // the time they get here, so every one of them must be HTML-escaped
  // before interpolation. Without this, a crafted `remark` could inject
  // markup/script into an email that actually lands in a real inbox
  // (Resend renders the html field as-is).
  const ref        = escapeHtml(input.ref);
  const token       = escapeHtml(input.token);
  const remark      = input.remark ? escapeHtml(input.remark) : '';
  const txHash      = escapeHtml(input.txHash);
  const walletAddr  = escapeHtml(input.walletAddress);
  const amount      = escapeHtml(String(input.amount));
  const recipients  = escapeHtml(String(input.recipientCount));

  return `
  <div style="font-family: 'DM Sans', Arial, sans-serif; max-width: 540px; margin: 0 auto; color: #0F172A;">
    <table role="presentation" cellpadding="0" cellspacing="0" border="0" style="width: 100%; border-collapse: collapse;">
      <tr>
        <td style="padding: 24px 0; border-bottom: 2px solid #4F46E5;">
          <table role="presentation" cellpadding="0" cellspacing="0" border="0">
            <tr>
              <td style="vertical-align: middle; padding-right: 10px;">
                <img src="${LOGO_URL}" alt="Salden" height="56" style="height: 56px; width: auto; display: block;" />
              </td>
              <td style="vertical-align: middle;">
                <span style="font-size: 20px; font-weight: 800; color: #4F46E5; letter-spacing: 0.02em;">SALDEN</span>
              </td>
            </tr>
          </table>
        </td>
      </tr>
    </table>
    <div style="padding: 24px 0;">
      <h2 style="font-size: 18px; font-weight: 700; color: #0F172A; margin: 0 0 12px;">Payroll Receipt — ${ref}</h2>
      <p style="font-size: 14px; color: #475569; line-height: 1.6; margin: 0 0 20px;">${summary}</p>

      <table style="width: 100%; border-collapse: collapse; font-size: 13px;">
        <tr><td style="padding: 8px 0; color: #64748B;">Reference</td><td style="padding: 8px 0; text-align: right; font-weight: 600;">${ref}</td></tr>
        <tr><td style="padding: 8px 0; color: #64748B;">Date</td><td style="padding: 8px 0; text-align: right; font-weight: 600;">${fmtDate}</td></tr>
        <tr><td style="padding: 8px 0; color: #64748B;">Recipients</td><td style="padding: 8px 0; text-align: right; font-weight: 600;">${recipients}</td></tr>
        <tr><td style="padding: 8px 0; color: #64748B;">Token</td><td style="padding: 8px 0; text-align: right; font-weight: 600;">${token}</td></tr>
        ${remark ? `<tr><td style="padding: 8px 0; color: #64748B;">Remark</td><td style="padding: 8px 0; text-align: right; font-weight: 600;">${remark}</td></tr>` : ''}
        <tr><td style="padding: 12px 0 8px; color: #0F172A; font-weight: 700; border-top: 1px solid #E2E8F0;">Total Amount</td><td style="padding: 12px 0 8px; text-align: right; font-weight: 800; font-size: 16px; color: #4F46E5; border-top: 1px solid #E2E8F0;">${amount} ${token}</td></tr>
      </table>

      <p style="font-size: 12px; color: #94A3B8; margin-top: 24px; word-break: break-all;">
        Transaction: ${txHash}<br/>
        Employer wallet: ${walletAddr}
      </p>
      <p style="font-size: 12px; color: #94A3B8; margin-top: 12px;">
        A full recipient-by-recipient breakdown is included in the attached PDF.
      </p>
    </div>
    <div style="padding: 20px 0; border-top: 1px solid #E2E8F0; font-size: 11px; color: #94A3B8;">
      Generated by Salden · Arc Testnet
    </div>
  </div>`;
}

export async function sendPayrollReceiptEmail(input: PayrollReceiptEmailInput): Promise<PayrollReceiptEmailResult> {
  try {
    const resend = getResendClient();
    const pdfBuffer = generateReceiptPdf(input);

    const { error } = await resend.emails.send({
      from:    FROM_ADDRESS,
      to:      input.recipientEmail,
      subject: `Salden Payroll Receipt — ${input.ref}`,
      html:    buildEmailHtml(input),
      attachments: [
        {
          filename: `salden-receipt-${input.ref}.pdf`,
          content:  pdfBuffer,
        },
      ],
    });

    if (error) {
      return { status: 'failed', message: error?.message ?? 'Payroll receipt could not be sent. Please try again.' };
    }

    return { status: 'sent', message: 'Payroll receipt email sent.' };
  } catch {
    return { status: 'failed', message: 'Payroll receipt could not be sent. Please try again.' };
  }
}

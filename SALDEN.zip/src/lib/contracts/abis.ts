/**
 * @file lib/contracts/abis.ts
 * Smart contract ABIs extracted from deployed contracts on Arc Testnet.
 */

// ─── SaldenEnterprisePayroll ABI (shared contract, free plan) ─────────────────
export const ENTERPRISE_PAYROLL_ABI = [
  {
    "inputs": [
      { "internalType": "address[]", "name": "employees", "type": "address[]" },
      { "internalType": "uint256[]", "name": "amounts", "type": "uint256[]" }
    ],
    "name": "batchPay",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "usdc",
    "outputs": [{ "internalType": "address", "name": "", "type": "address" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "MAX_BATCH_SIZE",
    "outputs": [{ "internalType": "uint256", "name": "", "type": "uint256" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "paused",
    "outputs": [{ "internalType": "bool", "name": "", "type": "bool" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "anonymous": false,
    "inputs": [
      { "indexed": true, "internalType": "address", "name": "caller", "type": "address" },
      { "indexed": false, "internalType": "uint256", "name": "count", "type": "uint256" },
      { "indexed": false, "internalType": "uint256", "name": "totalAmount", "type": "uint256" }
    ],
    "name": "BatchPaid",
    "type": "event"
  },
  // Custom errors — verified 1:1 against SaldenEnterprisePayroll.sol's own
  // `error` declarations. Without these, viem has no way to decode a
  // revert's 4-byte selector, so batchPay()/withdraw() failures on the
  // free-tier shared contract show as "execution reverted for an unknown
  // reason" instead of the real cause (this is the same class of bug
  // fixed on the premium factory — see MULTI_TOKEN_FACTORY_ABI below).
  { "inputs": [], "name": "ZeroAddress", "type": "error" },
  { "inputs": [], "name": "ZeroAmount", "type": "error" },
  { "inputs": [], "name": "ArrayLengthMismatch", "type": "error" },
  { "inputs": [], "name": "EmptyArray", "type": "error" },
  { "inputs": [{ "internalType": "uint256", "name": "provided", "type": "uint256" }, { "internalType": "uint256", "name": "max", "type": "uint256" }], "name": "BatchTooLarge", "type": "error" },
  { "inputs": [], "name": "NoFundsToWithdraw", "type": "error" },
  { "inputs": [], "name": "ETHNotAccepted", "type": "error" },
  // Bubbled up from Solady's SafeTransferLib, which SaldenEnterprisePayroll
  // uses internally for its USDC transfers — selectors are global (keyed
  // by the error's signature, not which contract "owns" it), so these
  // need to be here too or a transfer failure inside batchPay/withdraw
  // still can't be decoded even though the errors above are present.
  { "inputs": [], "name": "TransferFailed", "type": "error" },
  { "inputs": [], "name": "TransferFromFailed", "type": "error" }
] as const;

// ─── SaldenMultiTokenPayroll ABI (premium clone) ──────────────────────────────
export const MULTI_TOKEN_PAYROLL_ABI = [
  {
    "inputs": [{ "internalType": "address", "name": "initialOwner", "type": "address" }],
    "name": "initialize",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [
      { "internalType": "address[]", "name": "employees", "type": "address[]" },
      { "internalType": "uint256[]", "name": "amounts", "type": "uint256[]" },
      { "internalType": "address", "name": "token", "type": "address" }
    ],
    "name": "batchPay",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [{ "internalType": "address", "name": "account", "type": "address" }],
    "name": "addAgent",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [{ "internalType": "address", "name": "account", "type": "address" }],
    "name": "removeAgent",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [{ "internalType": "address", "name": "token", "type": "address" }],
    "name": "addSupportedToken",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "getSupportedTokens",
    "outputs": [{ "internalType": "address[]", "name": "", "type": "address[]" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [
      { "internalType": "uint256", "name": "offset", "type": "uint256" },
      { "internalType": "uint256", "name": "limit", "type": "uint256" }
    ],
    "name": "getSupportedTokensPaginated",
    "outputs": [{ "internalType": "address[]", "name": "result", "type": "address[]" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [{ "internalType": "address", "name": "token", "type": "address" }],
    "name": "withdraw",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [{ "internalType": "address", "name": "token", "type": "address" }],
    "name": "emergencyWithdraw",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "pause",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "unpause",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [{ "internalType": "address", "name": "", "type": "address" }],
    "name": "isAgent",
    "outputs": [{ "internalType": "bool", "name": "", "type": "bool" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [{ "internalType": "address", "name": "", "type": "address" }],
    "name": "isSupportedToken",
    "outputs": [{ "internalType": "bool", "name": "", "type": "bool" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "paused",
    "outputs": [{ "internalType": "bool", "name": "", "type": "bool" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "owner",
    "outputs": [{ "internalType": "address", "name": "", "type": "address" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "usdc",
    "outputs": [{ "internalType": "address", "name": "", "type": "address" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "MAX_BATCH_SIZE",
    "outputs": [{ "internalType": "uint256", "name": "", "type": "uint256" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [
      { "internalType": "address", "name": "newOwner", "type": "address" }
    ],
    "name": "transferOwnership",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "anonymous": false,
    "inputs": [
      { "indexed": true, "internalType": "address", "name": "caller", "type": "address" },
      { "indexed": true, "internalType": "address", "name": "token", "type": "address" },
      { "indexed": false, "internalType": "uint256", "name": "count", "type": "uint256" },
      { "indexed": false, "internalType": "uint256", "name": "totalAmount", "type": "uint256" }
    ],
    "name": "BatchPaid",
    "type": "event"
  },
  {
    "anonymous": false,
    "inputs": [{ "indexed": true, "internalType": "address", "name": "agent", "type": "address" }],
    "name": "AgentAdded",
    "type": "event"
  },
  {
    "anonymous": false,
    "inputs": [{ "indexed": true, "internalType": "address", "name": "agent", "type": "address" }],
    "name": "AgentRemoved",
    "type": "event"
  },
  {
    "anonymous": false,
    "inputs": [
      { "indexed": true, "internalType": "address", "name": "token", "type": "address" },
      { "indexed": true, "internalType": "address", "name": "addedBy", "type": "address" }
    ],
    "name": "TokenAdded",
    "type": "event"
  },
  // Custom errors — this ABI previously had NONE, meaning every revert from
  // batchPay/addAgent/removeAgent/addSupportedToken/withdraw/emergencyWithdraw
  // on the premium clone (including every one the AI agent's tool calls hit —
  // see lib/agent/toolExecutors.ts) showed as "execution reverted for an
  // unknown reason" instead of the real cause. Verified 1:1 against
  // SaldenMultiTokenPayrollFactory.sol's SaldenMultiTokenPayroll contract
  // section (the clone implementation), plus Solady's SafeTransferLib
  // errors it uses internally (global selectors, not contract-scoped).
  { "inputs": [], "name": "ZeroAddress", "type": "error" },
  { "inputs": [], "name": "ZeroAmount", "type": "error" },
  { "inputs": [], "name": "ArrayLengthMismatch", "type": "error" },
  { "inputs": [], "name": "EmptyArray", "type": "error" },
  { "inputs": [{ "internalType": "uint256", "name": "provided", "type": "uint256" }, { "internalType": "uint256", "name": "max", "type": "uint256" }], "name": "BatchTooLarge", "type": "error" },
  { "inputs": [], "name": "NoFundsToWithdraw", "type": "error" },
  { "inputs": [], "name": "ETHNotAccepted", "type": "error" },
  { "inputs": [], "name": "NotAuthorised", "type": "error" },
  { "inputs": [], "name": "AlreadyAgent", "type": "error" },
  { "inputs": [], "name": "NotCurrentlyAgent", "type": "error" },
  { "inputs": [], "name": "TokenAlreadySupported", "type": "error" },
  { "inputs": [], "name": "TokenNotSupported", "type": "error" },
  { "inputs": [], "name": "TransferFailed", "type": "error" },
  { "inputs": [], "name": "TransferFromFailed", "type": "error" }
] as const;

// ─── SaldenMultiTokenPayrollFactory ABI ───────────────────────────────────────
export const MULTI_TOKEN_FACTORY_ABI = [
  {
    "inputs": [],
    "name": "deployPayroll",
    "outputs": [{ "internalType": "address", "name": "clone", "type": "address" }],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [{ "internalType": "address", "name": "", "type": "address" }],
    "name": "payrollOf",
    "outputs": [{ "internalType": "address", "name": "", "type": "address" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "deployFee",
    "outputs": [{ "internalType": "uint256", "name": "", "type": "uint256" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "usdc",
    "outputs": [{ "internalType": "address", "name": "", "type": "address" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [{ "internalType": "uint256", "name": "newFee", "type": "uint256" }],
    "name": "setDeployFee",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "withdrawFees",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "anonymous": false,
    "inputs": [
      { "indexed": true, "internalType": "address", "name": "employer", "type": "address" },
      { "indexed": true, "internalType": "address", "name": "clone", "type": "address" },
      { "indexed": false, "internalType": "uint256", "name": "fee", "type": "uint256" }
    ],
    "name": "NewPayrollCreated",
    "type": "event"
  },
  // Custom errors — without these, viem can't decode a revert's 4-byte
  // selector into a readable message, so any of these show as a generic
  // "execution reverted for an unknown reason" instead of the real cause.
  { "inputs": [], "name": "ZeroAddress", "type": "error" },
  { "inputs": [], "name": "AlreadyDeployed", "type": "error" },
  { "inputs": [], "name": "NoFundsToWithdraw", "type": "error" },
  { "inputs": [{ "internalType": "uint256", "name": "provided", "type": "uint256" }, { "internalType": "uint256", "name": "max", "type": "uint256" }], "name": "FeeTooHigh", "type": "error" },
  { "inputs": [], "name": "ETHNotAccepted", "type": "error" },
  // These three were the actual missing piece behind the reported
  // "execution reverted for an unknown reason" on deployPayroll():
  // `deployPayroll()` collects the USDC fee via Solady's
  // `SafeTransferLib.safeTransferFrom` (reverts `TransferFromFailed()` on
  // insufficient balance/allowance — verified against Solady's
  // SafeTransferLib.sol source) and deploys the clone via
  // `LibClone.clone()` (reverts `DeploymentFailed()` — verified against
  // Solady's LibClone.sol). Neither was in this ABI, so even though
  // `AlreadyDeployed` above WAS already defined, viem had no way to tell
  // "you already have a clone" apart from "you don't have enough USDC" —
  // both looked identically like an undecodable revert.
  { "inputs": [], "name": "TransferFromFailed", "type": "error" },
  { "inputs": [], "name": "ApproveFailed", "type": "error" },
  { "inputs": [], "name": "DeploymentFailed", "type": "error" }
] as const;

// ─── SaldenRegistryFactory ABI ────────────────────────────────────────────────
export const REGISTRY_FACTORY_ABI = [
  {
    "inputs": [],
    "name": "createRegistry",
    "outputs": [{ "internalType": "address", "name": "clone", "type": "address" }],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [{ "internalType": "address", "name": "employer", "type": "address" }],
    "name": "getRegistry",
    "outputs": [{ "internalType": "address", "name": "", "type": "address" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "anonymous": false,
    "inputs": [
      { "indexed": true, "internalType": "address", "name": "hrAdmin", "type": "address" },
      { "indexed": true, "internalType": "address", "name": "clone", "type": "address" }
    ],
    "name": "RegistryCreated",
    "type": "event"
  },
  // Custom errors — this ABI had NONE, so createRegistry() failures (same
  // "already have one" / "deployment failed" class of bug as the payroll
  // factory above) were equally undecodable. `RegistryAlreadyExists`
  // verified against SaldenRegistryFactory.sol directly; `FailedDeployment`
  // is OpenZeppelin v5.1+'s shared Clones/Create2 failure error (this
  // factory uses OZ's `Clones.clone()`, not Solady's LibClone — confirmed
  // via the import in SaldenRegistryFactory.sol — so it needs OZ's error
  // name, not Solady's `DeploymentFailed`).
  { "inputs": [{ "internalType": "address", "name": "registry", "type": "address" }], "name": "RegistryAlreadyExists", "type": "error" },
  { "inputs": [], "name": "FailedDeployment", "type": "error" }
] as const;

// ─── SaldenRegistry (clone) ABI ───────────────────────────────────────────────
export const REGISTRY_ABI = [
  {
    "inputs": [{ "internalType": "address", "name": "initialHrAdmin", "type": "address" }],
    "name": "initialize",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [{ "internalType": "string", "name": "newCID", "type": "string" }],
    "name": "updateCID",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "getCID",
    "outputs": [{ "internalType": "string", "name": "", "type": "string" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "getCIDHash",
    "outputs": [{ "internalType": "bytes32", "name": "", "type": "bytes32" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [{ "internalType": "address", "name": "agent", "type": "address" }],
    "name": "addAgent",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [{ "internalType": "address", "name": "agent", "type": "address" }],
    "name": "removeAgent",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "hrAdmin",
    "outputs": [{ "internalType": "address", "name": "", "type": "address" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [{ "internalType": "address", "name": "", "type": "address" }],
    "name": "isAgent",
    "outputs": [{ "internalType": "bool", "name": "", "type": "bool" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [{ "internalType": "address", "name": "newAdmin", "type": "address" }],
    "name": "proposeAdminTransfer",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "acceptAdminTransfer",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  // Custom errors — verified 1:1 against SaldenRegistry.sol. Same class
  // of bug as MULTI_TOKEN_PAYROLL_ABI above: this had none, so any
  // revert from setCID/addAgent/removeAgent/proposeAdminTransfer/
  // acceptAdminTransfer showed as an undecodable "unknown reason".
  { "inputs": [], "name": "Unauthorized", "type": "error" },
  { "inputs": [], "name": "InvalidCID", "type": "error" },
  { "inputs": [], "name": "CIDAlreadySet", "type": "error" },
  { "inputs": [], "name": "AdminCannotBeAgent", "type": "error" },
  { "inputs": [], "name": "AlreadyAgent", "type": "error" },
  { "inputs": [], "name": "NotCurrentlyAgent", "type": "error" },
  { "inputs": [], "name": "NotPendingAdmin", "type": "error" },
  { "inputs": [], "name": "NoPendingTransfer", "type": "error" },
  { "inputs": [], "name": "InvalidAdminProposal", "type": "error" }
] as const;

// ─── ERC-20 ABI (for USDC allowance approval) ────────────────────────────────
export const ERC20_ABI = [
  {
    "anonymous": false,
    "inputs": [
      { "indexed": true, "internalType": "address", "name": "from", "type": "address" },
      { "indexed": true, "internalType": "address", "name": "to", "type": "address" },
      { "indexed": false, "internalType": "uint256", "name": "value", "type": "uint256" }
    ],
    "name": "Transfer",
    "type": "event"
  },
  {
    "inputs": [
      { "internalType": "address", "name": "spender", "type": "address" },
      { "internalType": "uint256", "name": "amount", "type": "uint256" }
    ],
    "name": "approve",
    "outputs": [{ "internalType": "bool", "name": "", "type": "bool" }],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [
      { "internalType": "address", "name": "to", "type": "address" },
      { "internalType": "uint256", "name": "amount", "type": "uint256" }
    ],
    "name": "transfer",
    "outputs": [{ "internalType": "bool", "name": "", "type": "bool" }],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [
      { "internalType": "address", "name": "owner", "type": "address" },
      { "internalType": "address", "name": "spender", "type": "address" }
    ],
    "name": "allowance",
    "outputs": [{ "internalType": "uint256", "name": "", "type": "uint256" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [{ "internalType": "address", "name": "account", "type": "address" }],
    "name": "balanceOf",
    "outputs": [{ "internalType": "uint256", "name": "", "type": "uint256" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "decimals",
    "outputs": [{ "internalType": "uint8", "name": "", "type": "uint8" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "symbol",
    "outputs": [{ "internalType": "string", "name": "", "type": "string" }],
    "stateMutability": "view",
    "type": "function"
  }
] as const;

// ─── Arc Memo Contract ABI ─────────────────────────────────────────────────────
// Predeployed on Arc Testnet: 0x5294E9927c3306DcBaDb03fe70b92e01cCede505
// Used to attach structured JSON memos to any contract call.
// Arc's predeployed Memo contract (0x5294...) — verified against the real
// contract ABI on the Arc Testnet block explorer. The function is `memo`,
// NOT `callWithMemo` — an earlier version of this file had the wrong
// function name and parameter shape entirely (a nonexistent function
// selector), which reverted on every single call. See the `memo`
// signature below: `memoId` is a caller-chosen bytes32 (this codebase
// derives it as keccak256 of the memo bytes — see callers), and the
// actual memo payload goes in `memoData`, not a trailing `value` param —
// this function is nonpayable.
export const MEMO_ABI = [
  {
    "inputs": [
      { "internalType": "address", "name": "target",   "type": "address" },
      { "internalType": "bytes",   "name": "data",     "type": "bytes"   },
      { "internalType": "bytes32", "name": "memoId",   "type": "bytes32" },
      { "internalType": "bytes",   "name": "memoData", "type": "bytes"   }
    ],
    "name": "memo",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [{ "internalType": "bytes", "name": "returnData", "type": "bytes" }],
    "name": "MemoFailed",
    "type": "error"
  },
  {
    "anonymous": false,
    "inputs": [
      { "indexed": true,  "internalType": "address", "name": "sender",       "type": "address" },
      { "indexed": true,  "internalType": "address", "name": "target",       "type": "address" },
      { "indexed": false, "internalType": "bytes32",  "name": "callDataHash", "type": "bytes32" },
      { "indexed": true,  "internalType": "bytes32",  "name": "memoId",      "type": "bytes32" },
      { "indexed": false, "internalType": "bytes",    "name": "memo",        "type": "bytes"   },
      { "indexed": false, "internalType": "uint256",  "name": "memoIndex",   "type": "uint256" }
    ],
    "name": "Memo",
    "type": "event"
  }
] as const;

export const MEMO_CONTRACT_ADDRESS = '0x5294E9927c3306DcBaDb03fe70b92e01cCede505' as const;

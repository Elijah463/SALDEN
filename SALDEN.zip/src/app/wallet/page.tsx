'use client';
/**
 * @file app/wallet/page.tsx
 * Wallet hub: hero balance, action cards, USDC/EURC/cirBTC token rows.
 *
 * Decimal note:
 *   Native balance (useBalance)     → 18 decimals → .formatted gives human value
 *   ERC-20 balanceOf (EURC, cirBTC) → 6/8 decimals → divide by 10^decimals
 *
 * Re-fetch strategy:
 *   nativeBalance (USDC) is read from useBalance hook — updates automatically.
 *   ERC-20 balances fetched once on mount / address change.
 *   nativeBalance is NOT in fetchTokenBalances useCallback deps to avoid
 *   continuous re-fetches on every block.
 */

import { useState, useEffect, useCallback, useRef } from 'react';
import { useRouter }        from 'next/navigation';
import { useBalance, usePublicClient } from 'wagmi';
import {
  Eye, EyeOff, Copy, ArrowDownToLine,
  Send, ArrowLeftRight, GitMerge, Loader2,
} from 'lucide-react';
import { AppLayout }        from '@/components/layout/AppLayout';
import { NetworkGuard }     from '@/components/shared/NetworkGuard';
import { useEffectiveAddress } from '@/lib/useEffectiveAddress';
import { useBalanceVisibility } from '@/lib/useBalanceVisibility';
import { ERC20_ABI }        from '@/lib/contracts/abis';
import { arcTestnet, CONTRACTS } from '@/lib/contracts/config';
import { copyToClipboard }  from '@/lib/clipboard';
import { tokenIconRenderSize } from '@/lib/token-registry';

// Next.js statically replaces `process.env.NEXT_PUBLIC_X` at build time only
// when it sees that exact literal expression in source — `process.env[someVar]`
// (dynamic/bracket access) can never be inlined this way, since the bundler
// doesn't know what `someVar` will be until runtime, and `process.env` isn't
// actually available in the browser bundle at runtime beyond what got
// inlined. Referencing both literals directly here (even though they're
// being placed into a lookup object) is what makes the build-time
// replacement work; the object itself is just a plain runtime lookup.
const ENV_TOKEN_ADDRESSES: Record<string, string | undefined> = {
  NEXT_PUBLIC_EURC_ADDRESS:   process.env.NEXT_PUBLIC_EURC_ADDRESS,
  NEXT_PUBLIC_CIRBTC_ADDRESS: process.env.NEXT_PUBLIC_CIRBTC_ADDRESS,
};

// ── Supported tokens ─────────────────────────────────────────────────────────

// Icons are sized to exactly fill TokenRow's 40x40 circular slot (see
// TOKEN_ICON_SIZE below) — no separate colored background/border behind
// them, so every row shows a clean, equally-sized token logo with no halo.
const TOKEN_ICON_SIZE = 40;

const TOKENS = [
  {
    symbol: 'USDC', name: 'USD Coin', color: '#2775CA', bgColor: '#EFF6FF',
    fromNative: true, decimals: 6, displayDecimals: 2,
    icon: (
      // eslint-disable-next-line @next/next/no-img-element
      <img src="/images/tokens/usdc.webp" alt="USDC" width={TOKEN_ICON_SIZE} height={TOKEN_ICON_SIZE}
        style={{ display: 'block', borderRadius: '50%', objectFit: 'cover' }} />
    ),
  },
  {
    symbol: 'EURC', name: 'Euro Coin', color: '#1B3A6B', bgColor: '#EEF2FF',
    fromNative: false, decimals: 6, displayDecimals: 2,
    envKey: 'NEXT_PUBLIC_EURC_ADDRESS',
    icon: (
      // eslint-disable-next-line @next/next/no-img-element
      <img src="/images/tokens/eurc.svg" alt="EURC"
        width={tokenIconRenderSize('EURC', TOKEN_ICON_SIZE)} height={tokenIconRenderSize('EURC', TOKEN_ICON_SIZE)}
        style={{ display: 'block', borderRadius: '50%', objectFit: 'cover' }} />
    ),
  },
  {
    // cirBTC trades at BTC-scale value, so real-world balances are commonly
    // small fractions (e.g. 0.00004) that a 2-decimal display rounds away
    // to "0.00" entirely. 6 decimal places, always shown in full (never
    // trimmed), so a real non-zero balance is never invisible.
    symbol: 'cirBTC', name: 'Circle Bitcoin', color: '#F7931A', bgColor: '#FFF7ED',
    fromNative: false, decimals: 8, displayDecimals: 6,
    envKey: 'NEXT_PUBLIC_CIRBTC_ADDRESS',
    icon: (
      // eslint-disable-next-line @next/next/no-img-element
      <img src="/images/tokens/cirbtc.png" alt="cirBTC" width={TOKEN_ICON_SIZE} height={TOKEN_ICON_SIZE}
        style={{ display: 'block', borderRadius: '50%', objectFit: 'cover' }} />
    ),
  },
];

// ── Action card ───────────────────────────────────────────────────────────────

function ActionCard({ icon, label, href }: { icon: React.ReactNode; label: string; href: string }) {
  const router = useRouter();
  return (
    <button
      onClick={() => router.push(href)}
      style={{
        flex: 1, minWidth: 70, display: 'flex', flexDirection: 'column',
        alignItems: 'center', gap: 10, padding: '16px 8px', borderRadius: 16,
        background: '#F8F9FA', border: '1.5px solid #F1F5F9',
        cursor: 'pointer', fontFamily: 'inherit', transition: 'all 0.15s',
      }}
      onMouseEnter={e => {
        (e.currentTarget as HTMLButtonElement).style.background = '#EEF2FF';
        (e.currentTarget as HTMLButtonElement).style.borderColor = '#C7D2FE';
      }}
      onMouseLeave={e => {
        (e.currentTarget as HTMLButtonElement).style.background = '#F8F9FA';
        (e.currentTarget as HTMLButtonElement).style.borderColor = '#F1F5F9';
      }}
    >
      <div style={{ width: 48, height: 48, borderRadius: 14, background: '#EEF2FF',
        display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        {icon}
      </div>
      <span style={{ fontSize: 13, fontWeight: 600, color: '#0F172A' }}>{label}</span>
    </button>
  );
}

// ── Token row ─────────────────────────────────────────────────────────────────

function TokenRow({ symbol, name, icon, balance, loading, usdValue }: {
  symbol: string; name: string; icon: React.ReactNode;
  balance: string; loading?: boolean; usdValue?: string | null;
}) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', padding: '14px 0',
      gap: 14, borderBottom: '1px solid #F1F5F9' }}>
      <div style={{ width: 40, height: 40, borderRadius: '50%', overflow: 'hidden',
        display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
        {icon}
      </div>
      <div style={{ flex: 1 }}>
        <div style={{ fontSize: 14, fontWeight: 700, color: '#0F172A' }}>{symbol}</div>
        <div style={{ fontSize: 12, color: '#94A3B8' }}>{name}</div>
      </div>
      <div style={{ textAlign: 'right' }}>
        <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 15, fontWeight: 700, color: '#0F172A' }}>
          {loading
            ? <Loader2 size={14} color="#94A3B8" style={{ animation: 'spin 0.7s linear infinite' }} />
            : balance
          }
        </div>
        {!loading && usdValue && (
          <div style={{ fontSize: 12, color: '#94A3B8' }}>≈${usdValue}</div>
        )}
      </div>
    </div>
  );
}

// ── Main page ─────────────────────────────────────────────────────────────────

export default function WalletPage() {
  const { address, isConnected: isAuth } = useEffectiveAddress();
  const publicClient = usePublicClient({ chainId: arcTestnet.id });

  const [showBalance,   setShowBalance]   = useBalanceVisibility();
  const [copied,        setCopied]        = useState(false);
  const [erc20Balances, setErc20Balances] = useState<Record<string, string>>({});
  const [loadingErc20,  setLoadingErc20]  = useState(false);

  // Native balance — 18 decimals on Arc; .formatted gives human-readable value
  const { data: nativeBalance } = useBalance({
    address: address as `0x${string}` | undefined,
    query: { enabled: !!address },
  });

  // Human-readable USDC balance from native balance
  const usdcDisplay = nativeBalance
    ? Number(nativeBalance.formatted).toLocaleString('en-US', {
        minimumFractionDigits: 2, maximumFractionDigits: 2,
      })
    : '0.00';

  // ERC-20 balances — nativeBalance intentionally excluded from deps
  // to avoid re-fetching on every block; USDC is shown from nativeBalance directly
  //
  // A transient RPC hiccup (Arc's public testnet RPC intermittently
  // rate-limits with HTTP 429) used to be indistinguishable from a
  // genuinely empty wallet: any failed balanceOf() read fell into the same
  // catch block that displayed "0.00", identical to what a real zero
  // balance shows. That's exactly the reported symptom — refreshing
  // sometimes shows the real balance and sometimes shows 0.00 for the same
  // funded wallet, purely depending on whether that particular read hit a
  // rate limit. Fixed the same way swap/page.tsx's fetchTokenBalance
  // already does it: retry a few times first (a rate limit is usually
  // gone within a second or two), and on total failure keep whatever
  // balance was last successfully read instead of overwriting it with a
  // fake zero — an unknown balance and a confirmed-zero balance are not
  // the same thing and shouldn't render the same way.
  const erc20BalancesRef = useRef(erc20Balances);
  useEffect(() => { erc20BalancesRef.current = erc20Balances; }, [erc20Balances]);

  const fetchErc20 = useCallback(async () => {
    if (!address || !publicClient) return;
    setLoadingErc20(true);
    const previous = erc20BalancesRef.current;
    const out: Record<string, string> = {};
    for (const t of TOKENS) {
      if (t.fromNative) continue;
      const addr = t.envKey
        ? (ENV_TOKEN_ADDRESSES[t.envKey] as `0x${string}` | undefined)
        : undefined;
      if (!addr) { out[t.symbol] = `0.${'0'.repeat(t.displayDecimals)}`; continue; }

      let resolved: string | null = null;
      for (let attempt = 1; attempt <= 3 && resolved === null; attempt++) {
        try {
          const raw = await publicClient.readContract({
            address: addr, abi: ERC20_ABI,
            functionName: 'balanceOf',
            args: [address as `0x${string}`],
          }) as bigint;
          const div   = BigInt(10 ** t.decimals);
          const whole = raw / div;
          const dp    = t.displayDecimals;
          const frac  = (raw % div).toString().padStart(t.decimals, '0').slice(0, dp).padEnd(dp, '0');
          resolved = `${Number(whole).toLocaleString()}.${frac}`;
        } catch {
          if (attempt < 3) await new Promise(r => setTimeout(r, 800));
        }
      }
      // Keep the last known-good value on total failure rather than
      // clobbering it with a fake "0.00" — see comment above.
      out[t.symbol] = resolved ?? previous[t.symbol] ?? `0.${'0'.repeat(t.displayDecimals)}`;
    }
    setErc20Balances(prev => ({ ...prev, ...out }));
    setLoadingErc20(false);
  }, [address, publicClient]);

  useEffect(() => { if (address) fetchErc20(); }, [address, fetchErc20]);

  // ── Total USD value across all tokens (hero card) — live prices via LI.FI ──
  const [tokenPrices, setTokenPrices] = useState<Record<string, number>>({});

  useEffect(() => {
    let cancelled = false;
    Promise.all(
      TOKENS.map(async t => {
        const addr = t.fromNative ? CONTRACTS.USDC
          : t.envKey ? (ENV_TOKEN_ADDRESSES[t.envKey] as `0x${string}` | undefined)
          : undefined;
        if (!addr) return [t.symbol, null] as const;
        try {
          const res = await fetch(`/api/lifi/price?chainId=${arcTestnet.id}&token=${addr}`);
          const data = await res.json() as { price: { priceUSD: string } | null };
          return [t.symbol, data.price ? Number(data.price.priceUSD) : null] as const;
        } catch {
          return [t.symbol, null] as const;
        }
      }),
    ).then(results => {
      if (cancelled) return;
      const map: Record<string, number> = {};
      for (const [symbol, price] of results) if (price !== null) map[symbol] = price;
      setTokenPrices(map);
    });
    return () => { cancelled = true; };
  }, []);

  const totalUsd = TOKENS.reduce((sum, t) => {
    const balanceStr = t.fromNative ? usdcDisplay : (erc20Balances[t.symbol] ?? '0');
    const balance = Number(balanceStr.replace(/,/g, '')) || 0;
    const price = tokenPrices[t.symbol] ?? (t.symbol === 'USDC' ? 1 : undefined); // USDC defaults to $1 if the live price hasn't loaded yet — everything else waits for a real price rather than guessing
    if (price === undefined) return sum;
    return sum + balance * price;
  }, 0);
  const totalUsdDisplay = totalUsd.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  // True only once every token with a nonzero balance has a resolved price
  // — while any are still missing, the total above is a partial sum, so we
  // label it "≈" rather than presenting it as exact.
  const allPricesLoaded = TOKENS.every(t => {
    const balanceStr = t.fromNative ? usdcDisplay : (erc20Balances[t.symbol] ?? '0');
    const balance = Number(balanceStr.replace(/,/g, '')) || 0;
    return balance === 0 || tokenPrices[t.symbol] !== undefined || t.symbol === 'USDC';
  });

  async function handleCopy() {
    if (!address) return;
    const ok = await copyToClipboard(address);
    if (ok) { setCopied(true); setTimeout(() => setCopied(false), 2000); }
  }

  return (
    <NetworkGuard>
      <AppLayout title="Wallet">
        <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>

          {/* Hero balance card */}
          <div style={{ background: '#4F46E5', borderRadius: 20, padding: '24px 28px',
            position: 'relative', overflow: 'hidden' }}>
            <div style={{ position: 'absolute', top: -40, right: -40, width: 160, height: 160,
              borderRadius: '50%', background: 'rgba(255,255,255,0.05)' }} />

            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 18 }}>
              <button onClick={() => setShowBalance(v => !v)}
                style={{ background: 'none', border: 'none', cursor: 'pointer',
                  color: 'rgba(255,255,255,0.75)', display: 'flex', padding: 0 }}>
                {showBalance ? <Eye size={16} /> : <EyeOff size={16} />}
              </button>
              <span style={{ fontSize: 13, fontWeight: 600, color: 'rgba(255,255,255,0.85)' }}>
                Wallet Balance
              </span>
            </div>

            <div style={{ fontSize: 38, fontWeight: 800, color: '#fff',
              letterSpacing: '-0.02em', marginBottom: 14 }}>
              {isAuth
                ? (showBalance ? `${allPricesLoaded ? '' : '≈'}$${totalUsdDisplay}` : '$••••••')
                : '$0.00'}
            </div>

            {isAuth && address ? (
              <button onClick={handleCopy} style={{
                display: 'flex', alignItems: 'center', gap: 8,
                background: 'rgba(255,255,255,0.12)', border: 'none', borderRadius: 8,
                padding: '6px 12px', cursor: 'pointer',
                fontFamily: "'JetBrains Mono', monospace", fontSize: 13,
                color: 'rgba(255,255,255,0.85)',
              }}>
                {address.slice(0, 8)}…{address.slice(-6)}
                <Copy size={13} color={copied ? '#14B8A6' : 'rgba(255,255,255,0.6)'} />
                {copied && <span style={{ fontSize: 11, color: '#14B8A6' }}>Copied!</span>}
              </button>
            ) : (
              <p style={{ fontSize: 13, color: 'rgba(255,255,255,0.6)', margin: 0 }}>
                Connect your wallet to view balance
              </p>
            )}
          </div>

          {/* Action cards */}
          <div style={{ display: 'flex', gap: 10 }}>
            <ActionCard icon={<ArrowDownToLine size={22} color="#4F46E5" />} label="Deposit" href="/wallet/deposit" />
            <ActionCard icon={<Send             size={22} color="#4F46E5" />} label="Send"    href="/wallet/send"    />
            <ActionCard icon={<ArrowLeftRight   size={22} color="#4F46E5" />} label="Swap"    href="/wallet/swap"    />
            <ActionCard icon={<GitMerge         size={22} color="#4F46E5" />} label="Bridge"  href="/wallet/bridge"  />
          </div>

          {/* Token balances */}
          <div style={{ background: '#fff', border: '1px solid #E2E8F0',
            borderRadius: 16, padding: '20px 20px 8px' }}>
            <h3 style={{ fontSize: 15, fontWeight: 700, color: '#0F172A', marginBottom: 4 }}>Tokens</h3>
            {TOKENS.map(token => {
              const balanceStr = token.fromNative ? usdcDisplay : (erc20Balances[token.symbol] ?? '0.00');
              const balanceNum = Number(balanceStr.replace(/,/g, '')) || 0;
              const price = tokenPrices[token.symbol] ?? (token.symbol === 'USDC' ? 1 : undefined);
              const usdValue = price !== undefined
                ? (balanceNum * price).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })
                : null;
              return (
                <TokenRow
                  key={token.symbol}
                  symbol={token.symbol}
                  name={token.name}
                  icon={token.icon}
                  loading={token.fromNative ? false : (loadingErc20 && !erc20Balances[token.symbol])}
                  balance={balanceStr}
                  usdValue={usdValue}
                />
              );
            })}
          </div>

        </div>
        <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
      </AppLayout>
    </NetworkGuard>
  );
}
